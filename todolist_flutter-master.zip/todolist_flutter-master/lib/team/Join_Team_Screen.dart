
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class JoinTeamScreen extends StatefulWidget{

  @override
  State<StatefulWidget> createState() =>
    _JoinTeamScreenState();
}
class _JoinTeamScreenState extends State<JoinTeamScreen>{
  @override
  Widget build(BuildContext context) {
   return Scaffold(
     backgroundColor: Colors.white,
     appBar: AppBar(
       backgroundColor: Colors.white,
       title: Text('请选择加入方式',style: TextStyle(color: Colors.black),),
       actions: <Widget>[
         FlatButton(onPressed: (){Navigator.pop(context);},
             child: Icon(Icons.arrow_back_ios_sharp))
       ],
     ),

     body:
     Container(
       width: double.infinity,
       height: double.infinity,
       color: Colors.white,
       child:Column(
       crossAxisAlignment: CrossAxisAlignment.center,
       mainAxisAlignment: MainAxisAlignment.center,
         children: [
          TouchBox("输入邀请码"),
           SizedBox(height: 50,),
           TouchBox("扫描二维码"),
         ],
       ),)
     );
  }
}
Widget TouchBox(contains){
  return
    Container(
      width: 350,
      height: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),

        boxShadow: [
          BoxShadow(
            color: Color(0xff000000),
            blurRadius: 0.5,
            offset: Offset(0.0, 1.0),
          ),
        ],
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            Colors.white
          ],
        ),
      ),
      child:
      FlatButton(
        child:
        Row(
            children:[
              Text(contains,textAlign: TextAlign.start, textScaleFactor: 3,style: TextStyle(color: Colors.black)),
            SizedBox(width:60),
            Icon(Icons.keyboard_arrow_right_sharp)
            ]),
      ),
    );
}