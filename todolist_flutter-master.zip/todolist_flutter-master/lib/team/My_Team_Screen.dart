import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_list/loding_container.dart';
import 'package:todo_list/sqlite/TeamDbProvider.dart';
import 'package:todo_list/sqlite/TeamModel.dart';
import 'package:todo_list/team/Team.dart';

import 'Create_Team_Screen.dart';

class MyTeamScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() =>  MyTeamScreenState();
}

class MyTeamScreenState extends State<MyTeamScreen>with TickerProviderStateMixin{
  bool _loading = true;
  List<Team> teams = [];
  double _scale;
  AnimationController _controller;

  @override
  void initState() {
    super.initState();
    select();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 200),
      lowerBound: 0.0,
      upperBound: 0.1,
    )..addListener(() {
      setState(() {});
    });
  }
  _toggleTodo(Team team) {
    setState(() {
    });
    update(team);
  }

  _addTodo() async {
    setState(() {
      _loading = true;
    });
    final team = await showDialog<Team>(
      context: context,
      builder: (BuildContext context) {
        return CreateTeamScreen();
      },//创建新任务
    );

    if (team != null) {
      setState(() {
        teams.add(team);
      });
    }
    setState(() {
      _loading = false;
    });
  }
  select() async {
    TeamDbProvider provider = new TeamDbProvider();
    TeamModels teamModels = await provider.getUserInfo();
    try {
      teamModels.teamModel.forEach((model) {
        print(model);
        teams.add(new Team(title: model.title, id: model.id,TeamId: model.teamid ));
        print(teams);
      });
    } catch (e) {
      print(e);
    }
    ;
    setState(() {
      _loading = false;
    });
  }

  //修改(controller的值获取不到，只能传值获取)
  Future update(Team team) async {
    TeamDbProvider provider = new TeamDbProvider();
    TeamModel userModel = await provider.getPersonInfo();
    userModel.id = team.id;
    userModel.title = team.title;
    userModel.teamid = team.TeamId;
    provider.update(userModel);
  }
  //删除
  Future delete(value) async {
    TeamDbProvider provider = new  TeamDbProvider();
    TeamModel userModel = await provider.getPersonInfo();
    userModel.id = value;
    provider.delete(userModel);
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _onTapUp(TapUpDetails details) {
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    _scale = 1-_controller.value;
   return Scaffold(
     appBar: AppBar(
       title: Text('我加入的群组'),
       actions: <Widget>[
       ],
     ),
     body: Column(
       crossAxisAlignment: CrossAxisAlignment.center,
       mainAxisAlignment: MainAxisAlignment.center,
       children: [
         LoadingContainer(isLoading: _loading, child:
         GestureDetector(
           onTapDown: _onTapDown,
           onTapUp: _onTapUp,
           child: Transform.scale(
             scale: _scale,
             child: CreateTeamView(teams),
           ),))
       ],
     ),
     floatingActionButton: FloatingActionButton(
       child: Icon(Icons.add),
       onPressed: _addTodo,
     ),
   );
  }
}

Widget CreateTeamView (teams){
  return ListView.builder(
    itemCount: teams.length,
    itemBuilder: (context, index) {
      return
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
      boxShadow: [
      BoxShadow(
      color: Color(0xFF000000),
      blurRadius: 1.0,
      offset: Offset(0.0, 1.0),
      ),
      ],
      gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
      Color(0xFFA7BFE8),
      Color(0xFF6190E8),
      ],
      ),
          ),
          // Key
          key: Key(UniqueKey().toString()),
          // Child
          child:  ListTile(
            title:  Text(teams[index].title),
            subtitle: Text(teams[index].TeamId),
          ),

        );
    },
  );
}