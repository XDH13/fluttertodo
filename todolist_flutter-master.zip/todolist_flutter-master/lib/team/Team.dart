class Team {
  Team({this.title,this.id,this.TeamId});
  int id;
  String title;
  String TeamId;
}//team bean
