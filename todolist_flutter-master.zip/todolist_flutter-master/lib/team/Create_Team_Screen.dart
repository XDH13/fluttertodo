import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:todo_list/sqlite/PersonDbProvider.dart';
import 'package:todo_list/sqlite/TeamDbProvider.dart';
import 'package:todo_list/sqlite/TeamModel.dart';

import 'Team.dart';
class CreateTeamScreen extends StatefulWidget{
    @override
    State<StatefulWidget> createState() =>  CreateTeamScreenState();
}

class CreateTeamScreenState extends State<CreateTeamScreen>{
  String type = "请选择行业类型";
  final controller_of_teamname = new TextEditingController();
  final controller_of_num = new TextEditingController();
  //增加（不需要id 自增）
  Future insert(String value,String Team) async{
    TeamDbProvider provider = new TeamDbProvider();
    TeamModel userModel= TeamModel();
    userModel.title=value;
    userModel.teamid = Team;
    return provider.insert(userModel);
  }
  Future update(String value) async{
    TeamDbProvider provider = new TeamDbProvider();
    TeamModel userModel= await provider.getPersonInfo();
//    userModel.id=int.parse(value);
//    userModel.mobile="00000";
    provider.update(userModel);
  }
  //删除
  Future delete(String value) async{
    TeamDbProvider provider = new TeamDbProvider();
    TeamModel userModel= await provider.getPersonInfo();
    userModel.id=int.parse(value);
    provider.delete(userModel);
  }
  //查询
  Future select()async{
    TeamDbProvider provider = new TeamDbProvider();
    TeamModels teamModels= await provider.getUserInfo();
    teamModels.teamModel.forEach((model){
      print(model);
    });
  }


  @override
  Widget build(BuildContext context) {
    return
      Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                Colors.lightBlue
              ],
            ),
          ),
     child:AlertDialog(
      title: Text("完善团队信息"),
      content: SingleChildScrollView(
        child: Column(
          children: [
            Container(
                child: TextField(
                  controller: controller_of_teamname,
                  autofocus: true,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.all(0),//输入框修饰
                    hintText: "请填写真实的团队名称",
                    hintStyle: TextStyle(fontSize: 20.0, color: Colors.redAccent),//设置提示文字样式
                    ),
                  ),
                ),
          Row(
              children: [
            Container(
              child:
              DropdownButton(icon: Icon(Icons.arrow_right), iconSize: 60, iconEnabledColor: Colors.green.withOpacity(0.6),
                  hint: Text('请选择行业类型'),
                  value: type,
                  autofocus: true,
                  items: [
                    DropdownMenuItem(child: Text('学院'), value: '学院'),
                    DropdownMenuItem(child: Text('班级'), value: '班级'),
                    DropdownMenuItem(child: Text('社团'), value: '社团'),
                    DropdownMenuItem(child: Text('其他'), value: '其他'),
                    DropdownMenuItem(child: Text('请选择行业类型'), value: '请选择行业类型'),
                  ].toList(),
                  onChanged: (value) {
                  controller_of_num.text=value.toString();
                  type = value.toString();
                  setState(() {
                    type = value.toString();
                  });
                  }
              ),
            ),
            Expanded(child: SizedBox()),
            ]
    ),
              ]
        )
              ),
           actions: [
             FlatButton(
               child: Text('Cancel'),
               onPressed: () {
                 Navigator.of(context).pop();
               },
             ),
             FlatButton(
               child: Text('Add'),
               onPressed: () async {
                 int lastID = await insert(controller_of_teamname.value.text,controller_of_num.text);
                 print(lastID);
                 final team = new Team(title: controller_of_teamname.value.text,id:lastID,TeamId:controller_of_num.text );
                 controller_of_teamname.clear();
                 controller_of_num.clear();
                 Navigator.of(context).pop(team);
                 Fluttertoast.showToast(msg: '添加团队成功');
               },
             ),
           ],
    )
      );
  }
}
