
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../new_todo_dialog.dart';
import '../todo_list_screen.dart';
import 'Create_Team_Screen.dart';
import 'Join_Team_Screen.dart';
import 'My_Team_Screen.dart';

class TeamScreen extends StatefulWidget{
  @override
  _TeamPageScreenState createState() => _TeamPageScreenState();
}

class _TeamPageScreenState extends State<TeamScreen>with TickerProviderStateMixin{
  double _scale;
  double _scale2;
  double _scale3;
  AnimationController _controller;
  AnimationController _controller2;
  AnimationController _controller3;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 200),
      lowerBound: 0.0,
      upperBound: 0.1,
    )..addListener(() {
      setState(() {});
    });
    _controller2 = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 200),
      lowerBound: 0.0,
      upperBound: 0.1,
    )..addListener(() {
      setState(() {});
    });
    _controller3 = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 200),
      lowerBound: 0.0,
      upperBound: 0.1,
    )..addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _onTapUp(TapUpDetails details) {
    _controller.reverse();
  }
  @override
  void dispose2() {
    _controller2.dispose();
    super.dispose();
  }

  void _onTapDown2(TapDownDetails details) {
    _controller2.forward();
  }

  void _onTapUp2(TapUpDetails details) {
    _controller2.reverse();
  }
  @override
  void dispose3() {
    _controller3.dispose();
    super.dispose();
  }

  void _onTapDown3(TapDownDetails details) {
    _controller3.forward();
  }

  void _onTapUp3(TapUpDetails details) {
    _controller3.reverse();
  }
  String mainTitle() {
    if (DateTime.now().hour < 5)
      return '夜深了!';
    else if (DateTime.now().hour < 9)
      return '早上好!';
    else if (DateTime.now().hour < 12)
      return '上午好!';
    else if (DateTime.now().hour < 13)
      return '中午好!';
    else if (DateTime.now().hour < 18)
      return '下午好!';
    else
      return '晚上好!';
  }
  @override
  Widget build(BuildContext context) {
    _scale = 1 - _controller.value;
    _scale2 = 1 - _controller2.value;
    _scale3 = 1 - _controller3.value;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('Hi, ' + mainTitle(),
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.w700,
            )),
        actions: <Widget>[],
      ),
          body:Container(
            width: double.infinity,
            height: double.infinity,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children:<Widget> [
                GestureDetector(
                  onTapDown: _onTapDown,
                  onTapUp: _onTapUp,
                  onTap:() {
               Navigator.push(
                  context,
                 new MaterialPageRoute(builder: (context) => new JoinTeamScreen()),
                  );
                  },
                  child: Transform.scale(
                    scale: _scale,
                    child: TouchBox("加入新群组","通过输入邀请码或扫描二维码加入你的班级、社团或其他北洋ToDo群组，接受公共ToDo提醒或与他人共享你的ToDo提醒。"),
                  ),),
                SizedBox(height: 20),
                GestureDetector(
                  onTapDown: _onTapDown2,
                  onTapUp: _onTapUp2,
                  onTap: () {
                Navigator.push(
                  context,
                  new MaterialPageRoute(builder: (context) => new NewTodoDialog()),
                );
              },
                  child: Transform.scale(
                    scale: _scale2,
                    child: TouchBox("创建新群组","创建新群组后，你将成为管理员，可以邀请他人进入群组，管理组织架构和群组类型，并向他们共享你的ToDo提醒。"),
                  ),),
                SizedBox(height: 20),
                GestureDetector(
                  onTapDown: _onTapDown3,
                  onTapUp: _onTapUp3,
                  onTap: () {
                    Navigator.push(
                      context,
                      new MaterialPageRoute(builder: (context) => new  TodoListScreen()),
                    );
                  },
                  child: Transform.scale(
                    scale: _scale3,
                    child: TouchBox("我的群组","管理你创建或作为管理员的的群组，解散、退出群组，转让管理权限或邀请他人进入群组。你也可以退出你加入的其他群组。"),
                  ),),
              ],
            ),
          ),
    );
  }
  }


Widget TouchBox(contains,subcontains){
 return
   Container(
    width: 350,
    height: 100,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5),

      boxShadow: [
        BoxShadow(
          color: Color(0xff000000),
          blurRadius: 0.5,
          offset: Offset(0.0, 1.0),
        ),
      ],
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white,
          Colors.white
        ],
      ),
    ),
    child:
    FlatButton(
      child:
      Column(
        children:[
          SizedBox(height: 4),
        Row
          (children:[Text(contains,textAlign: TextAlign.start, textScaleFactor: 1.5,style: TextStyle(color: Colors.black),),]
        ),
        Row(
            children:[
          Container(
            width: 300,
          padding: EdgeInsets.only(left: 5),
          decoration: new BoxDecoration(
            border:Border(left: BorderSide(color: Colors.blue,width: 2)),
          ),
          child: Text(subcontains,textAlign: TextAlign.start, textScaleFactor: 1,softWrap: true),
        )])
        ]),
    ),
  );
}
  // tend_myteam(BuildContext context) { Navigator.push(context, MaterialPageRoute(builder: (context) {
  //   return  MyTeamScreen();
  // }));}

  
