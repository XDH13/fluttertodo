class Todo {
  Todo({this.title,this.id, this.date,this.isDone = false});
  int id;
  String title;
  String date;
  bool isDone;
}//todo bean
