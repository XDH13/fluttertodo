import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PersonalView extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
          children: <Widget>[
            Container(
              height: 800,
              child: MediaQuery.removePadding(
                  context: context,
                  removeTop: true,
                  child: ListView(
                    children: <Widget>[
                      Container(
                          height: 200,
                          color: Colors.white,
                          child: Container(
                            margin: EdgeInsets.only(left: 30, top: 100, bottom: 25),
                            child: Row(
                              children: <Widget>[
                                Container(
                                  height: 75,
                                  width: 75,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      image: DecorationImage(
                                          fit: BoxFit.fitHeight,
                                          image: AssetImage('Images/laisha.png'))),
                                ),
                                Expanded(
                                    child: Container(
                                      padding: EdgeInsets.only(left: 15, right: 10),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[
                                          Container(
                                            child: Row(
                                              children: <Widget>[
                                                Text(
                                                  'XDH13',
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    fontSize: 25,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            height: 35,
                                          ),
                                          Container(
                                            child: Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  'xdh13',
                                                  style: TextStyle(
                                                      fontSize: 17, color: Colors.grey),
                                                ),
                                                Icon(Icons.keyboard_arrow_right_sharp,size: 20,)
                                              ],
                                            ),
                                            height: 35,
                                          )
                                        ],
                                      ),
                                    ))
                              ],
                            ),
                          )),
                      Container(
                        height: 10,
                      ), //灰色分组
                     ListTile(
                        title: Text('修改头像'),
                      ),
                      Container(
                        height: 10,
                      ),
                      ListTile(
                        title: Text('修改昵称'),
                      ),
                      Row(
                        children: <Widget>[
                          Container(width: 50, height: 0.5, color: Colors.white),
                          Container(height: 0.5, color: Colors.grey)
                        ],
                      ), //分割线
                      ListTile(
                        title: Text('学号'),
                      ),
                      Row(
                        children: <Widget>[
                          Container(width: 50, height: 0.5, color: Colors.white),
                          Container(height: 0.5, color: Colors.grey)
                        ],
                      ), //分割线
                      ListTile(
                        title: Text('姓名'),
                      ),
                      Row(
                        children: <Widget>[
                          Container(width: 50, height: 0.5, color: Colors.white),
                          Container(height: 0.5, color: Colors.grey)
                        ],
                      ), //分割线
                      ListTile(
                        title: Text('学院'),
                      ),
                      Container(
                        height: 10,
                      ), //灰色分组
                      ListTile(
                        title: Text('专业'),
                      ),
                    ],
                  )),
            ),
            Container(
              margin: EdgeInsets.only(top: 50, right: 20),
              height: 25,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Icon(Icons.camera_alt,size: 25,)
                ],
              ),
            ),
          ],
        ));
  }

}