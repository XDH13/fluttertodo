import 'dart:collection';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_custom_calendar/constants/constants.dart';
import 'package:flutter_custom_calendar/controller.dart';
import 'package:flutter_custom_calendar/flutter_custom_calendar.dart';
import 'package:flutter_custom_calendar/utils/LogUtil.dart';
import 'package:todo_dev/task/task_new.dart';
import 'package:todo_dev/res/data.dart';
import 'package:todo_dev/task/task_main.dart';
import 'BottomNavigation.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          focusColor: Colors.teal),
      home: TabsPage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  CalendarController controller;
  CalendarViewWidget calendar;
  HashSet<DateTime> _selectedDate = new HashSet();
  HashSet<DateModel> _selectedModels = new HashSet();
  int DayToUse;
  int MonthToUse;
  int YearToUse;
  List<TaskViewModel> searchResultTime = [];
  Text priorityText(int priority) {
    if (priority == 1)
      return Text('');
    else if (priority == 2)
      return Text('!',
          style: TextStyle(
            color: Colors.amber,
            fontWeight: FontWeight.w700,
            fontSize: 20,
          ));
    else if (priority == 3)
      return Text('!!',
          style: TextStyle(
            color: Colors.amber[900],
            fontWeight: FontWeight.w700,
            fontSize: 20,
          ));
    else
      return Text('!!!',
          style: TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.w700,
            fontSize: 20,
          ));
  }

  GlobalKey<CalendarContainerState> _globalKey = new GlobalKey();
  @override
  void initState() {
    _selectedDate.add(DateTime.now());
    controller = new CalendarController(
        minYear: 2018,
        minYearMonth: 1,
        maxYear: 2021,
        maxYearMonth: 12,
        showMode: CalendarConstants.MODE_SHOW_WEEK_AND_MONTH,
        selectedDateTimeList: _selectedDate,
        selectMode: CalendarSelectedMode.singleSelect)
      ..addOnCalendarSelectListener((dateModel) {
        _selectedModels.add(dateModel);
        setState(() {
          _selectDate = _selectedModels.toString();
        });
      })
      ..addOnCalendarUnSelectListener((dateModel) {
        LogUtil.log(TAG: '_selectedModels', message: _selectedModels.toString());
        LogUtil.log(TAG: 'dateModel', message: dateModel.toString());
        if (_selectedModels.contains(dateModel)) {
          _selectedModels.remove(dateModel);
        }else{
          DayToUse = controller.calendarProvider.lastClickDateModel.day;
          MonthToUse = controller.calendarProvider.lastClickDateModel.month;
          YearToUse=controller.calendarProvider.lastClickDateModel.year;
        }
        setState(() {
          _selectDate = _selectedModels.toString();
        });
      });
    calendar = new CalendarViewWidget(
      key: _globalKey,
      calendarController: controller,
      dayWidgetBuilder: (DateModel model) {
        double wd = (MediaQuery.of(context).size.width - 20) / 7;
        bool _isSelected = model.isSelected;
        if (_isSelected &&
            CalendarSelectedMode.singleSelect ==
                controller.calendarConfiguration.selectMode) {
          _selectDate = model.toString();
          DayToUse = controller.calendarProvider.lastClickDateModel.day;
          MonthToUse = controller.calendarProvider.lastClickDateModel.month;
          YearToUse=controller.calendarProvider.lastClickDateModel.year;
          SearchDate(YearToUse,MonthToUse,DayToUse);
        }
        return ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(wd/2)),
          child: Container(
            decoration: _isSelected? new BoxDecoration(
              border: Border.all(color: Colors.blue,width: 2,),
              borderRadius:BorderRadius.all(Radius.circular(wd/2)),
            )
                : new BoxDecoration(),
            alignment: Alignment.center,

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child:Text(
                    model.day.toString(),
                    style: TextStyle(
                        color: model.isCurrentMonth
                            ? (_isSelected == false
                            ? (model.isWeekend
                            ? Colors.red
                            : Colors.black26)
                            : Colors.black87)
                            : Colors.black38),
                  ),

                ),
                Text(model.traditionFestival.toString()),
              ],
            ),
          ),
        );
      },
    );
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.addExpandChangeListener((value) {
        // 添加改变 月视图和 周视图的监听
        _isMonthSelected = value;
        setState(() {});
      });
    });
    super.initState();
  }
  bool _isMonthSelected = false;
  String _selectDate = "";
  String mainTitle() {
    if (DateTime.now().hour < 5)
      return '夜深了!';
    else if (DateTime.now().hour < 9)
      return '早上好!';
    else if (DateTime.now().hour < 12)
      return '上午好!';
    else if (DateTime.now().hour < 13)
      return '中午好!';
    else if (DateTime.now().hour < 18)
      return '下午好!';
    else
      return '晚上好!';
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          actions: <Widget>[
          ],
          title:  Text('Hi, ' + mainTitle(),
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w700,
              )),
        ),

        body: CupertinoScrollbar(
          child: CustomScrollView(
            slivers: <Widget>[
              //  _topButtons(),
              _topMonths(),
              SliverToBoxAdapter(
                child: calendar,
              ),
              SliverToBoxAdapter(
                child: Container(
                  child:
                  MonthWidget(YearToUse,MonthToUse,DayToUse),
                  height: 100,
                  width: 100,
                ),
              ),
            ],
          ),
        ),
    );
  }
  Widget _topMonths() {
    return SliverToBoxAdapter(
      child: Wrap(
        direction: Axis.vertical,
        crossAxisAlignment: WrapCrossAlignment.start,
        children: <Widget>[
          Wrap(
            children: <Widget>[
              Container(
                decoration: _isMonthSelected?new BoxDecoration(
                    color: Colors.white,
                    border: Border(
                        bottom: BorderSide(
                            width: 3,
                            color: Colors.blue
                        )
                    )
                ):new BoxDecoration(
                    color: Colors.white
                ),
                width: MediaQuery.of(context).size.width/3,
                child: FlatButton(
                  child: Text(
                    '月视图',
                    style: _isMonthSelected ?TextStyle(color: Colors.blue,):
                    TextStyle(color: Colors.black),

                  ),
                  onPressed: () {
                    setState(() {
                      controller.weekAndMonthViewChange(
                          CalendarConstants.MODE_SHOW_ONLY_WEEK);
                    });
                  },
                  //color: _isMonthSelected ? Colors.teal : Colors.black38,
                ),

              ),
              Container(
                decoration: _isMonthSelected?new BoxDecoration(
                    color: Colors.white
                ):new BoxDecoration(
                    color: Colors.white,
                    border: Border(
                        bottom: BorderSide(
                            width: 3,
                            color: Colors.blue
                        )
                    )
                ),
                width: MediaQuery.of(context).size.width/3,
                child: FlatButton(
                  child: Text(
                    '周视图',
                    style: _isMonthSelected ? TextStyle(color: Colors.black):TextStyle(color: Colors.blue)
                    ,
                  ),
                  onPressed: () {
                    setState(() {
                      controller.weekAndMonthViewChange(
                          CalendarConstants.MODE_SHOW_ONLY_MONTH);
                    });
                  },
                  //   color: _isMonthSelected == false ? Colors.teal : Colors.black38,
                ),
              ),
              Container(
                color: Colors.white,
                width: MediaQuery.of(context).size.width/3,
                child: FlatButton(
                  child: Text(
                    '每日',
                    style: TextStyle(color: Colors.black),
                  ),
                  onPressed: (){
                    Navigator.push(
                      context,
                      new MaterialPageRoute(builder: (context) => new TaskMain()),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  bool SearchDate(int year,int month,int day){
    searchResultTime = [];
    bool has = false;
    for (int i = 0; i < taskData.length; i++) {
      var temp = taskData[i].task;
      for (int j = 0; j < temp.length; j++)
        if (temp[j].time.year==year&&temp[j].time.month==month&&temp[j].time.day==day) {
          searchResultTime.add(temp[j]);
          has = true;
        }
    }
    return has;
  }
  Widget MonthWidget(int year,int month,int day){
    bool istask = SearchDate(year,month,day);

    if(!istask){
      searchResultTime.add(TaskViewModel(name:"今天没有预定哦",
          time: DateTime(1979, 1, 1, 1,1, 1),
          key: 1,
          weight: 2));
      print("set lastClickDateModel:$day");
    }
    return Column(
      children: [
        Expanded(
            child: SingleChildScrollView(
                child: ListView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: searchResultTime.length,
                    itemBuilder: (context, index) {
                      TextEditingController _controller =
                      TextEditingController();
                      String time = searchResultTime[index].time.toString();
                      _controller.text = searchResultTime[index].name;
                      return Padding(
                        padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
                        child: TextField(
                          enableInteractiveSelection: false,
                          controller: _controller,
                          onTap: () async {
                            FocusScope.of(context).requestFocus(FocusNode());
                            await Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => TaskNew()));
                            setState(() {});
                          },
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              suffixIcon: Center(
                                widthFactor: 1,
                                child: priorityText(searchResultTime[index].weight),
                              ),
                              suffixText: time.substring(0, time.length - 7),
                              suffixStyle: TextStyle(fontSize: 12)),
                        ),
                      );
                    })))
      ],
    );
  }


}

