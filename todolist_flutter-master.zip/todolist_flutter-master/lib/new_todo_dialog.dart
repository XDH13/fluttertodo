import 'package:flutter/material.dart';
import 'package:todo_list/sqlite/PersonDbProvider.dart';
import 'package:todo_list/sqlite/TodoModel.dart';
import 'package:todo_list/todo.dart';

class NewTodoDialog extends StatefulWidget {
  @override
    State<StatefulWidget> createState() =>  NewTodoDialogState();
}

class NewTodoDialogState extends State<NewTodoDialog>{
  String type = "请选择行业类型";
  final controller_of_con = new TextEditingController();
  final controller_of_num = new TextEditingController();
  //增加（不需要id 自增）
  Future insert(String value,String dates) async{
    PersonDbProvider provider = new PersonDbProvider();
    TodoModel userModel= TodoModel();
    // userModel.id=int.parse(controller.value.text);
    userModel.title=value;
    userModel.isDone="false";
    userModel.date = dates;
    return provider.insert(userModel);
  }
  //修改(controller的值获取不到，只能传值获取)
  Future update(String value) async{
    PersonDbProvider provider = new PersonDbProvider();
    TodoModel userModel= await provider.getPersonInfo();
//    userModel.id=int.parse(value);
//    userModel.mobile="00000";
    provider.update(userModel);
  }
  //删除
  Future delete(String value) async{
    PersonDbProvider provider = new PersonDbProvider();
    TodoModel userModel= await provider.getPersonInfo();
    userModel.id=int.parse(value);
    provider.delete(userModel);
  }
  //查询
  Future select()async{
    PersonDbProvider provider = new PersonDbProvider();
    TodoModels todoModels= await provider.getUserInfo();
    todoModels.todoModel.forEach((model){
      print(model);
    });
  }


  @override
  Widget build(BuildContext context) {
    return
      Container(
        color: Colors.white,
          child:
          AlertDialog(
      title: Text('建立新的群组'),
      content:
      SingleChildScrollView(
          child: Container(
              child: Column(
                  children:[
                    TextField(
                      controller: controller_of_con,
                      autofocus: true,
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(0),//输入框修饰
                        hintText: "请填写真实的团队名称",
                        hintStyle: TextStyle(fontSize: 20.0, color: Colors.redAccent),//设置提示文字样式
                      ),
                    ),
                    Row(
                        children: [
                          Container(
                            child:
                            DropdownButton(icon: Icon(Icons.arrow_right), iconSize: 60, iconEnabledColor: Colors.green.withOpacity(0.6),
                                hint: Text('请选择行业类型'),
                                value: type,
                                autofocus: true,
                                items: [
                                  DropdownMenuItem(child: Text('学院'), value: '学院'),
                                  DropdownMenuItem(child: Text('班级'), value: '班级'),
                                  DropdownMenuItem(child: Text('社团'), value: '社团'),
                                  DropdownMenuItem(child: Text('其他'), value: '其他'),
                                  DropdownMenuItem(child: Text('请选择行业类型'), value: '请选择行业类型'),
                                ].toList(),
                                onChanged: (value) {
                                  controller_of_num.text=value.toString();
                                  type = value.toString();
                                  setState(() {
                                    type = value.toString();
                                  });
                                }
                            ),
                          ),
                          Expanded(child: SizedBox()),
                        ]
                    ),
                  ]
              )
          )
      ),
      actions: <Widget>[
        FlatButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        FlatButton(
          child: Text('Add'),
          onPressed: () async {
//            select();
//            update(controller.value.text);
            int lastID = await insert(controller_of_con.value.text,controller_of_num.value.text);
            print(lastID);
//            delete(controller.value.text);
            final todo = new Todo(title: controller_of_con.value.text,id:lastID,date:controller_of_num.value.text );
            controller_of_con.clear();
            Navigator.of(context).pop(todo);
          },
        ),
      ],
    ));
  }
}

