import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:todo_list/loding_container.dart';
import 'package:todo_list/sqlite/PersonDbProvider.dart';
import 'package:todo_list/sqlite/TodoModel.dart';
import 'package:todo_list/team/team_screen.dart';
import 'package:todo_list/todo.dart';
import 'package:todo_list/new_todo_dialog.dart';

typedef ToggleTodoCallback = void Function(Todo, bool);

class TodoListScreen extends StatefulWidget {
  @override
  _TodoListScreenState createState() => _TodoListScreenState();
}

class _TodoListScreenState extends State<TodoListScreen> {
  bool _loading = true;
  List<Todo> todos = [];
  _toggleTodo(Todo todo, bool isChecked) {
    setState(() {
      todo.isDone = isChecked;
    });
    update(todo);
  }

  _addTodo() async {
    setState(() {
      _loading = true;
    });
    final todo = await showDialog<Todo>(
      context: context,
      builder: (BuildContext context) {
        return NewTodoDialog();
      },//创建新任务
    );

    if (todo != null) {
      setState(() {
        todos.add(todo);
      });
    }
    setState(() {
      _loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    select();
  }

  select() async {
    PersonDbProvider provider = new PersonDbProvider();
    TodoModels todoModels = await provider.getUserInfo();
    try {
      todoModels.todoModel.forEach((model) {
        print(model);
        bool isDone = model.isDone == "true";
        print(isDone);
        todos.add(new Todo(title: model.title, id: model.id, isDone: isDone,date: model.date));///Todo 把日历的datamodel加到这里
        print(todos);
      });
    } catch (e) {
      print(e);
    }
    ;
    setState(() {
      _loading = false;
    });
  }

  //修改(controller的值获取不到，只能传值获取)
  Future update(Todo todo) async {
    PersonDbProvider provider = new PersonDbProvider();
    TodoModel userModel = await provider.getPersonInfo();
    userModel.id = todo.id;
    userModel.isDone = todo.isDone.toString();
    userModel.title = todo.title;
    userModel.date = todo.date;
    provider.update(userModel);
  }
  //删除
  Future delete(value) async {
    PersonDbProvider provider = new PersonDbProvider();
    TodoModel userModel = await provider.getPersonInfo();
    userModel.id = value;
    provider.delete(userModel);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('我的群组',style: TextStyle(color: Colors.black),),
        actions: <Widget>[
          FlatButton(onPressed: (){Navigator.pop(context);},
            child: Icon(Icons.arrow_back_ios_sharp))],
      ),
      body:

        LoadingContainer(
          isLoading: _loading, child: _createListView(todos, _toggleTodo)),
    );
  }

  // 创建ListView
  Widget _createListView(todos, onTodoToggle) {
    return ListView.separated(
        separatorBuilder: (BuildContext context, int index) =>
            Divider(
              height: 5.0,
              color: Color(0xFFFFFFFF),
            ),
      itemCount: todos.length,
      itemBuilder: (context, index) {
        return
          Dismissible(
            background: Container(
              color: Colors.green,
            // 这里使用 ListTile 因为可以快速设置左右两端的Icon
            child: ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.white,
              ),
            ),
          ),

          secondaryBackground: Container(
            color: Colors.red,
            // 这里使用 ListTile 因为可以快速设置左右两端的Icon
            child: ListTile(
              trailing: Icon(
                Icons.delete,
                color: Colors.white,
              ),
            ),
          ),
          // Key
          key: Key(UniqueKey().toString()),
          // Child
          child:
         Row(
             children:[
               SizedBox(width: 20,),
               Container(
            width: 350,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(width: 2,color: Colors.black12),
              boxShadow: [
                BoxShadow(
                  color: Color(0xff000000),
                  blurRadius: 5.0,
                  offset: Offset(0.0, 1.0),
                ),
              ],
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white,
                  Colors.white
                ],
              ),
            ),
            child:ListTile(
            title: todos[index].isDone
                ? Text(
                    todos[index].title,
                    style: TextStyle(
                      color: Colors.grey,
                      decoration: TextDecoration.lineThrough,
                      decorationColor: Colors.grey,
                    ),//这个是点击后会变灰并加一条线
                  )
                : Text(todos[index].title),
            subtitle: todos[index].isDone
                ? Text(
              todos[index].date,
              style: TextStyle(
                color: Colors.grey,
                decoration: TextDecoration.lineThrough,
                decorationColor: Colors.grey,
              ),//这个是点击后会变灰并加一条线
            )
                : Text(todos[index].date),
          ),)]),
          onDismissed: (direction) {
            delete(todos[index].id);
            setState(() {
              todos.removeAt(index);
            });
          },
          confirmDismiss: (direction) async {
            var _confirmContent;
            var _alertDialog;
            // 从右向左  也就是删除
            _confirmContent = '确认删除:${todos[index].title}？';
            _alertDialog = AlertDialog(
              title: Text(_confirmContent),
              actions: <Widget>[
                FlatButton(
                  onPressed: () {
                    Navigator.of(context).pop(true);//连带true一起返回
                  },
                  child: Text('确认'),
                ),
                FlatButton(
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  child: Text('取消'),
                )
              ],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20))),
            );
            var isDismiss = await showDialog(
                context: context,
                builder: (BuildContext context) {
                  return _alertDialog;
                });
            return isDismiss;//点了确认就确定删除
          },
        );
      },
    );

  }
}
