/**
 * Created with IntelliJ IDEA.
 * Package: db
 */
class TodoModels {
  //定义变量
  final List<TodoModel> todoModel;

//定义构造方法
  TodoModels(
      {
        this.todoModel,
      });

//定义工厂方法
  factory TodoModels.fromJson(List<dynamic> listJson) {
    List<TodoModel> todoModel =
    listJson.map((value) => TodoModel.fromJson(value)).toList();
    return TodoModels(
      todoModel: todoModel,
    );
  }
}
class TodoModel {
  //定义变量
   int id;
   String title;
   int lastid;
   String isDone;
   String date;
  //构造方法
  TodoModel({
    this.id,
    this.lastid,
    this.title,
    this.isDone,
    this.date,
  });

  //创建工厂方法
  factory TodoModel.fromJson(Map<String, dynamic> json) {
    //动态类型
    return TodoModel(
      id: json['id'],
      lastid: json['LAST_INSERT_ROWID()'],
      title: json['title'],
      isDone: json['isDone'],
      date: json['date'],
    );
  }
   Map<String, dynamic> toJson() {
     return {
       'id': id,
       'lastid': lastid,
       'title': title,
       'isDone': isDone,
       'date':date,
     };
   }
}
