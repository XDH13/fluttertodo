
import 'package:sqflite/sqflite.dart';
import 'package:meta/meta.dart';
import 'package:todo_list/sqlite/sqlite.dart';

/**
 * Description:数据库
 */

abstract class BaseDbProvider {
  bool isTableExits = false;

  createTableString();

  tableName();

  insertTableHello();

  ///创建表sql语句
  tableBaseString(String sql) {
    return sql;
  }

  Future<Database> getDataBase() async {
    return await open();
  }

  ///super 函数对父类进行初始化
  @mustCallSuper
  prepare(name, String createSql,String insertHello) async {
    isTableExits = await SqlManager.isTableExits(name);
    if (!isTableExits) {
      Database db = await SqlManager.getCurrentDatabase();
      await db.execute(createSql);
      return await db.execute(insertHello);
    }
  }

  @mustCallSuper
  open() async {
    if (!isTableExits) {
      await prepare(tableName(), createTableString(),insertTableHello());
    }
    return await SqlManager.getCurrentDatabase();
  }

}
