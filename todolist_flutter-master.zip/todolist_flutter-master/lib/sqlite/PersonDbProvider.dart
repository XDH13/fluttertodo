import 'dart:async';
import 'dart:convert';

import 'package:sqflite/sqlite_api.dart';
import 'package:todo_list/sqlite/BaseDB.dart';
import 'package:todo_list/sqlite/TodoModel.dart';


/**
 * Package: db
 * Description:数据库表
 */

class PersonDbProvider extends BaseDbProvider{
  ///表名
  final String name = 'TodoInfo';
  final String columnId="id";
  final String columnTitle="title";
  final String columnIsDone="isDone";
  final String columnDate = 'date';

  PersonDbProvider();

  @override
  tableName() {
    return name;/// todo
  }

  @override
  createTableString() {
    return '''
        create table $name (
        $columnId integer primary key,$columnTitle text not null,$columnIsDone text not null,$columnDate text not null)
      ''';
  }
  @override
  insertTableHello(){
    return '''
        insert into $name ($columnTitle,$columnIsDone,$columnDate) values ("左右滑动可以删除你的不开心哦！","false","114")
      ''';
  }
  ///查询数据库
  Future _getPersonProvider(Database db) async {
    List<Map<String, dynamic>> maps =
    await db.rawQuery("select * from $name ");
    return maps;
  }

  ///插入到数据库
  Future insert(TodoModel model) async {
    Database db = await getDataBase();
    var userProvider = await _getPersonProvider(db);
    if(model.id!=null){
      if (userProvider != null) {
        ///删除数据
        await db.delete(name, where: "$columnId = ?", whereArgs: [model.id]);
      }
    }
    await db.rawInsert("insert into $name ($columnTitle,$columnIsDone,$columnDate) values (?,?,?)",[model.title,model.isDone,model.date]);
    List<Map<String, dynamic>> maps =
    await db.rawQuery(    "SELECT LAST_INSERT_ROWID();", null);
    if (maps.length > 0) {
      TodoModel userModel = await TodoModel.fromJson(maps[0]);
      return userModel.lastid;
    }
    return null;
  }

  ///更新数据库
  Future<void> update(TodoModel model) async {
    Database database = await getDataBase();
    await database.rawUpdate(
        "update $name set $columnTitle = ?,$columnIsDone = ?,$columnDate = ? where $columnId= ?",[model.title,model.isDone,model.date,model.id]);

  }

  ///删除数据
  Future<void> delete(TodoModel model) async {
    Database database = await getDataBase();
    await database.delete(name, where: "$columnId = ?", whereArgs: [model.id]);

  }

  ///获取事件数据
  Future<TodoModel> getPersonInfo() async {
    Database db = await getDataBase();
    List<Map<String, dynamic>> maps  = await _getPersonProvider(db);
    if (maps.length > 0) {
      return TodoModel.fromJson(maps[0]);
    }
    return null;
  }

  ///获取全部数据
  Future<TodoModels> getUserInfo() async {
    Database db = await getDataBase();
    final maps  = await _getPersonProvider(db);
    if (maps.length > 0) {
      return TodoModels.fromJson(maps);
    }
    return null;
  }
}