import 'BaseDB.dart';
import 'package:sqflite/sqlite_api.dart';
import 'package:todo_list/sqlite/BaseDB.dart';

import 'TeamModel.dart';

class TeamDbProvider extends BaseDbProvider{
  final String name = 'TeamInfo';
  final String columnId="id";
  final String columnTitle="title";
  final String columnTeamId = "teamnum";
  @override
  createTableString() {
    return '''
        create table $name (
        $columnId integer primary key,
        $columnTitle text not null,
        $columnTeamId text not null,)
      ''';
  }

  @override
  insertTableHello(){
    return '''
        insert into $name ($columnTitle,$columnTitle,$columnTeamId) values ("左右滑动可以删除你的不开心哦！","false","114")
      ''';
  }

  @override
  tableName() {
   return name;
  }
  ///查询数据库
  Future _getPersonProvider(Database db) async {
    List<Map<String, dynamic>> maps =
    await db.rawQuery("select * from $name ");
    return maps;
  }

  ///插入到数据库
  Future insert(TeamModel model) async {
    Database db = await getDataBase();
    var userProvider = await _getPersonProvider(db);
    if(model.id!=null){
      if (userProvider != null) {
        ///删除数据
        await db.delete(name, where: "$columnId = ?", whereArgs: [model.id]);
      }
    }
    await db.rawInsert("insert into $name ($columnTitle,$columnTeamId) values (?,?)",[model.title,model.teamid]);
    List<Map<String, dynamic>> maps =
    await db.rawQuery(    "SELECT LAST_INSERT_ROWID();", null);
    if (maps.length > 0) {
      TeamModel userModel = await TeamModel.fromJson(maps[0]);
      return userModel.lastid;
    }
    return null;
  }

  ///更新数据库
  Future<void> update(TeamModel model) async {
    Database database = await getDataBase();
    await database.rawUpdate(
        "update $name set $columnTitle = ?,$columnTeamId = ? where $columnId= ?",[model.title,model.teamid,model.id]);

  }

  ///删除数据
  Future<void> delete(TeamModel model) async {
    Database database = await getDataBase();
    await database.delete(name, where: "$columnId = ?", whereArgs: [model.id]);
  }

  ///获取事件数据
  Future<TeamModel> getPersonInfo() async {
    Database db = await getDataBase();
    List<Map<String, dynamic>> maps  = await _getPersonProvider(db);
    if (maps.length > 0) {
      return TeamModel.fromJson(maps[0]);
    }
    return null;
  }

  ///获取全部数据
  Future<TeamModels> getUserInfo() async {
    Database db = await getDataBase();
    final maps  = await _getPersonProvider(db);
    if (maps.length > 0) {
      return TeamModels.fromJson(maps);
    }
    return null;
  }
}