class TeamModels {
  //定义变量
  final List<TeamModel> teamModel;

//定义构造方法
  TeamModels(
      {
        this.teamModel,
      });

//定义工厂方法
  factory TeamModels.fromJson(List<dynamic> listJson) {

    List<TeamModel> teamModel =
    listJson.map((value) => TeamModel.fromJson(value)).toList();
    return TeamModels(
      teamModel: teamModel,
    );
  }
}
class TeamModel {
  //定义变量
  int id;
  String title;
  int lastid;
  String teamid;
  //构造方法
  TeamModel({
    this.id,
    this.title,
    this.lastid,
    this.teamid,
  });

  //创建工厂方法
  factory TeamModel.fromJson(Map<String, dynamic> json) {
    //动态类型
    return TeamModel(
      id: json['id'],
      title: json['title'],
      lastid: json['LAST_INSERT_ROWID()'],
      teamid: json['TeamId'],
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'lastid': lastid,
      'TeamId':teamid,
    };
  }
}