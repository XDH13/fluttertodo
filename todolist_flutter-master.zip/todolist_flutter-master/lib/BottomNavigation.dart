import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_dev/task/task_main.dart';
import 'package:todo_list/team/team_screen.dart';
import 'package:todo_list/todo_list_screen.dart';
import 'package:todo_list/team/Create_Team_Screen.dart';
import 'Person/Personal.dart';
import 'main.dart';
class TabsPage extends StatefulWidget {
  TabsPage({Key key}) : super(key: key);
  @override
  _TabsPageState createState() => _TabsPageState();
}

class _TabsPageState extends State<TabsPage> {
  int currentIndex = 0;
  List listTabs = [
    MyHomePage(),
    TaskMain(),
    TeamScreen(),
    PersonalView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: this.listTabs[this.currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: this.currentIndex,
        iconSize: 30.0,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() {
            this.currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            title: Text('日历'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            title: Text('代办'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people_rounded),
            title: Text('团队'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            title: Text('个人'),
          ),
        ],
      ),
    );
  }
}